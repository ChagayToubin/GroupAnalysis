from classify_server.objects.temp_dir import TempDir


class Manager:

    def __init__(self, db_handler, consumer, text_classified, visual_classified, categories):
        self.db_handler = db_handler
        self.consumer = consumer
        self.text_classified = text_classified
        self.visual_classified = visual_classified
        self.categories = categories


    def manage(self):
        for msg in self.consumer.consume():
            file_id = msg.value["file_id"]
            with TempDir() as dir_path:
                his_type, file_path, text = self.db_reader.write_file_from_gridfs(file_id, dir_path)
                if his_type == "video":
                    category = self.video_handler(file_path, text)
                elif his_type == "audio":
                    category = self.audio_handler(file_path, text)
                elif his_type == "text":
                    category = self.text_handler(file_path)
                elif his_type == "image":
                    category = self.image_handler(file_path, text)
                if category:
                    self.db_reader.update_metadata_by_id(file_id, "classification", category)




    def video_handler(self, file_path, text = None) -> str:
        pass

    def audio_handler(self, file_path, text = None) -> str:
        pass

    def text_handler(self, file_path) -> str:
        pass

    def image_handler(self, file_path, text = None) -> str:
        pass






